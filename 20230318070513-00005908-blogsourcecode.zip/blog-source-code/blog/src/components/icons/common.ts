export interface IconProps {
    isActive?: boolean;
}
