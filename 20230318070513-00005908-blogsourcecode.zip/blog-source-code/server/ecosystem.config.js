module.exports = {
    apps: [
        {
            name: "ingrao-blog",
            script: "yarn",
            args: "start",
        },
    ],
};
