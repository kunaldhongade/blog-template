declare module 'draftjs-utils' {
  declare var exports: {
    changeDepth: () => {},
    getSelectedBlocksType: () => {},
    getEntityRange: () => {},
    getSelectionText: () => {},
    getSelectionEntity: () => {},
  }
}
