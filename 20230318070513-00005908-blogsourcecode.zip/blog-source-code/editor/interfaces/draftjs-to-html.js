declare module 'draftjs-to-html' {
  declare var exports: {
    draftToHtml: () => {}
  }
}
