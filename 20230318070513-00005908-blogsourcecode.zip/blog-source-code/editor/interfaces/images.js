declare module 'images' {
  declare var exports: { [key: string]: string };
}
