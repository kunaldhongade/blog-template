declare module 'CSSModule' {
  declare var exports: { [key: string]: string };
}
